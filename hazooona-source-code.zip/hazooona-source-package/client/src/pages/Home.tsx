import { useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";

type Screen =
  | "intro"
  | "passcode"
  | "wrong"
  | "nickname"
  | "message"
  | "photos-0"
  | "photos-1"
  | "photos-2"
  | "photos-3"
  | "final";

const photos = [
  "/manus-storage/photo-1_9dbc740b.jpg",
  "/manus-storage/photo-2_51d4d0a0.jpg",
  "/manus-storage/photo-3_8cf17a7f.jpg",
  "/manus-storage/photo-4_9a06eb7f.jpg",
  "/manus-storage/photo-5_d2e2daca.jpg",
  "/manus-storage/photo-6_4ccfa079.jpg",
  "/manus-storage/photo-7_c6af0d05.jpg",
];

const galleries = [
  { title: "يزن الجميل", layout: "side", indexes: [0, 1], next: "photos-1" as Screen },
  { title: "البروو اللطيف", layout: "stack", indexes: [2, 3], next: "photos-2" as Screen },
  { title: "أحن يزن", layout: "diagonal", indexes: [4, 5], next: "photos-3" as Screen },
  { title: "أحلى مهندس", layout: "center", indexes: [6], next: "final" as Screen },
];

function Cat({ mood = "happy" }: { mood?: "happy" | "sad" }) {
  return (
    <div className={`cat-container ${mood === "sad" ? "is-sad" : ""}`} aria-hidden="true">
      <div className="cat">
        <div className="cat-head">
          <span className="cat-ear left" />
          <span className="cat-ear right" />
          <span className="cat-eye left" />
          <span className="cat-eye right" />
          <span className="cat-nose" />
          <span className="cat-mouth" />
          <span className="cat-cheek left" />
          <span className="cat-cheek right" />
          <span className="cat-bow"><i /></span>
          {mood === "sad" && <><span className="tear left" /><span className="tear right" /></>}
        </div>
        <div className="cat-body" />
        <span className="cat-paw left" />
        <span className="cat-paw right" />
      </div>
    </div>
  );
}

function PrimaryButton({ children, onClick, secondary = false }: { children: ReactNode; onClick: () => void; secondary?: boolean }) {
  return <button className={`btn ${secondary ? "btn-secondary" : ""}`} onClick={onClick}>{children}</button>;
}

export default function Home() {
  const [screen, setScreen] = useState<Screen>("intro");
  const [passcode, setPasscode] = useState("");
  const [shake, setShake] = useState(false);

  const particles = useMemo(
    () => Array.from({ length: 18 }, (_, index) => ({
      id: index,
      icon: ["✦", "♡", "✧", "🦋"][index % 4],
      left: `${(index * 17 + 5) % 97}%`,
      top: `${(index * 23 + 4) % 94}%`,
      delay: `${(index % 7) * 0.8}s`,
      duration: `${11 + (index % 5) * 2}s`,
    })),
    [],
  );

  useEffect(() => {
    if (passcode.length !== 3) return;
    const timer = window.setTimeout(() => {
      if (passcode === "119") {
        setScreen("nickname");
        setPasscode("");
      } else {
        setScreen("wrong");
        setPasscode("");
      }
    }, 360);
    return () => window.clearTimeout(timer);
  }, [passcode]);

  const goTo = (next: Screen) => {
    setScreen(next);
    setShake(false);
  };

  const enterDigit = (digit: number) => {
    if (passcode.length < 3) setPasscode((current) => current + digit);
  };

  const clearPasscode = () => setPasscode((current) => current.slice(0, -1));

  const renderScreen = () => {
    if (screen === "intro") {
      return (
        <section className="screen active" aria-label="المقدمة">
          <div className="card intro-card reveal">
            <div className="eyebrow">A LITTLE SURPRISE FOR YOU</div>
            <Cat />
            <p className="kicker">I made something for you</p>
            <h1>Wanna see it<span className="soft-pink">?!</span></h1>
            <p className="arabic-subtitle">جاهز لمفاجأة صغيرة يا هزون؟</p>
            <PrimaryButton onClick={() => goTo("passcode")}>YES!! <span>→</span></PrimaryButton>
            <div className="tiny-note">made with love · just for you</div>
          </div>
        </section>
      );
    }

    if (screen === "passcode") {
      return (
        <section className="screen active" aria-label="الرقم السري">
          <div className="card passcode-card reveal">
            <div className="eyebrow">PRIVATE ACCESS</div>
            <h2>Enter a passcode</h2>
            <p className="muted">three little numbers to unlock your surprise</p>
            <div className={`passcode-display ${shake ? "shake" : ""}`} aria-label="الرمز المدخل">
              {[0, 1, 2].map((index) => <span key={index} className={`passcode-dot ${index < passcode.length ? "filled" : ""}`}>{index < passcode.length ? "•" : ""}</span>)}
            </div>
            <div className="keypad" aria-label="لوحة الأرقام">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => <button className="key" key={digit} onClick={() => enterDigit(digit)}>{digit}</button>)}
              <span className="key ghost" />
              <button className="key" onClick={() => enterDigit(0)}>0</button>
              <button className="key erase" onClick={clearPasscode} aria-label="مسح">⌫</button>
            </div>
            <button className="back-link" onClick={() => goTo("intro")}>← رجوع</button>
          </div>
        </section>
      );
    }

    if (screen === "wrong") {
      return (
        <section className="screen active" aria-label="رمز خاطئ">
          <div className="card reveal wrong-card">
            <div className="status-icon">!</div>
            <div className="eyebrow">ALMOST THERE</div>
            <h2>Wrong passcode</h2>
            <p className="muted arabic-subtitle">القطة زعلت شوي… جرّب مرة ثانية</p>
            <Cat mood="sad" />
            <PrimaryButton secondary onClick={() => goTo("passcode")}>TRY AGAIN <span>↗</span></PrimaryButton>
          </div>
        </section>
      );
    }

    if (screen === "nickname") {
      return (
        <section className="screen active" aria-label="اللقب">
          <div className="card reveal name-card">
            <div className="eyebrow">FOR YOU <span className="heart">♥</span></div>
            <div className="name-script">Hazoona</div>
            <div className="ornament"><span />✦<span /></div>
            <p className="arabic-subtitle">لأنك شخص مميز جدًا…</p>
            <PrimaryButton onClick={() => goTo("message")}>NEXT <span>→</span></PrimaryButton>
          </div>
        </section>
      );
    }

    if (screen === "message") {
      return (
        <section className="screen active" aria-label="الرسالة">
          <div className="card message-card reveal">
            <div className="eyebrow">A NOTE FOR YOU</div>
            <h2>Happy Birthday <span className="heart">♥</span></h2>
            <div className="message-box arabic-text">
              <p>هاابيي بيرثدايي ي بطتيي وعقبال كل أعوامكك تقضيهم بخير وهنا وسعادة وحب وطاعة وراحة بال</p>
              <p>وإن شاء الله يكون عام تحقيق أحلامك وكل إشي ببالك يا <strong>أجدعع مهندسس</strong> وأحلى يزنن،،</p>
              <p>احمم 🌝 مش محتاج الموضوع أحكيهه بس عامكك هاد هيكون أحلى من كل لقبل لأنك تعرفت عع <strong>حداا زيي</strong> 😂♥</p>
              <p className="message-ending">يلل يبروو إنجويي بيومكك يا أحلى هزونن بحياتيي 😂♥✨</p>
            </div>
            <PrimaryButton onClick={() => goTo("photos-0")}>تشوف الحلويات؟ <span>→</span></PrimaryButton>
          </div>
        </section>
      );
    }

    if (screen.startsWith("photos-")) {
      const galleryIndex = Number(screen.split("-")[1]);
      const gallery = galleries[galleryIndex];
      return (
        <section className="screen active" aria-label={`الصور ${galleryIndex + 1}`}>
          <div className="card photo-card reveal">
            <div className="eyebrow">MEMORIES · {String(galleryIndex + 1).padStart(2, "0")}/04</div>
            <h2 className="photo-title">{gallery.title} <span className="heart">♥</span></h2>
            <div className={`photos-grid layout-${gallery.layout}`}>
              {gallery.indexes.map((photoIndex, index) => (
                <div className={`polaroid stagger-${index + 1}`} key={photos[photoIndex]}>
                  <img src={photos[photoIndex]} alt={`صورة يزن ${photoIndex + 1}`} loading="eager" decoding="async" />
                  <span className="photo-mark">✦</span>
                </div>
              ))}
            </div>
            <PrimaryButton onClick={() => goTo(gallery.next)}>{galleryIndex === 3 ? "تشوف؟" : galleryIndex === 0 ? "تكمل !!" : galleryIndex === 1 ? "لسّاع فيي 🌝" : "التالي"} <span>→</span></PrimaryButton>
            <div className="dots-nav" aria-label="تقدم الصور">{galleries.map((_, index) => <span className={index === galleryIndex ? "active" : ""} key={index} />)}</div>
          </div>
        </section>
      );
    }

    return (
      <section className="screen active" aria-label="النهاية">
        <div className="card reveal final-card">
          <div className="final-ribbon">YOU ARE LOVED</div>
          <Cat />
          <p className="final-text arabic-text">صنع بحب منن رهوفة ليزونن <span>♥✨</span></p>
          <div className="ornament"><span />✦<span /></div>
          <h2>Happy birthday brooo <span className="heart">♥✨</span></h2>
          <div className="final-emojis">🥺 <span>🐣</span> 🦆 ✨</div>
          <button className="restart-link" onClick={() => goTo("intro")}>ابدأ من جديد</button>
        </div>
      </section>
    );
  };

  return (
    <main className="birthday-app">
      <div className="ambient-glow glow-one" />
      <div className="ambient-glow glow-two" />
      <div className="particles" aria-hidden="true">{particles.map((particle) => <span key={particle.id} style={{ left: particle.left, top: particle.top, animationDelay: particle.delay, animationDuration: particle.duration }}>{particle.icon}</span>)}</div>
      <div className="brand-stamp">H<span>♥</span>Z</div>
      {renderScreen()}
      <div className="progress-label">{screen === "intro" ? "01" : screen === "passcode" ? "02" : screen === "wrong" ? "02" : screen === "nickname" ? "03" : screen === "message" ? "04" : screen.startsWith("photos-") ? `0${Number(screen.split("-")[1]) + 5}` : "09"} <span>/</span> 09</div>
    </main>
  );
}
